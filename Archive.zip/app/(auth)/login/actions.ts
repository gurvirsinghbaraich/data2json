"use server";

import { getSupabaseClient } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function emailSignUp(formData: FormData) {
  const supabase = getSupabaseClient();

  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (!error) {
    return redirect("/");
  }

  revalidatePath("/", "layout");
  return redirect("/login?error=INVALID_CREDENTIALS");
}
