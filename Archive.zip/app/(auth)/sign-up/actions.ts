"use server";

import { getSupabaseClient } from "@/utils/supabase";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function emailLogin(formData: FormData) {
  const supabase = getSupabaseClient();

  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  await supabase.auth.signUp({
    email,
    password,
  });

  revalidatePath("/", "layout");
  return redirect("/");
}
