"use server";
import { getSupabaseClient } from "@/utils/supabase";
import { redirect } from "next/navigation";

export async function logoutUser() {
  const supabase = getSupabaseClient();
  await supabase.auth.signOut();

  redirect("/login");
}
